
import streamlit as st
import pandas as pd
import numpy as np
import folium
from streamlit_folium import st_folium
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

st.set_page_config(page_title="CASEFILE AI", page_icon="📍", layout="wide")

st.title("📍 CASEFILE: AI-Powered Missing Person Investigation")
st.caption("Academic simulation using synthetic case information. Predictions are probabilistic and are not evidence of a person's real location.")

DATA = "data/processed/movement_features.csv"
CASES = "data/synthetic/missing_person_cases.csv"

df = pd.read_csv(DATA, parse_dates=["Timestamp"])
cases = pd.read_csv(CASES)

AREA_COORDS = {
    "Area_A": (23.2599, 77.4126),
    "Area_B": (23.2480, 77.4340),
    "Area_C": (23.2710, 77.3980),
    "Area_D": (23.2350, 77.4210),
    "Area_E": (23.2850, 77.4400),
}

# Sidebar
st.sidebar.header("Case Selection")
case_id = st.sidebar.selectbox("Select fictional case", cases["Case_ID"])
case = cases[cases["Case_ID"] == case_id].iloc[0]

# Clustering
cluster_features = ["Latitude","Longitude","Speed_kmh","Distance_km"]
scaler = StandardScaler()
X_cluster = scaler.fit_transform(df[cluster_features])
kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_cluster)

# Anomaly detection
anom_features = ["Latitude","Longitude","Speed_kmh","Distance_km","Hour"]
iso = IsolationForest(n_estimators=150, contamination=0.05, random_state=42)
df["Anomaly"] = iso.fit_predict(df[anom_features])
df["Anomaly_Label"] = np.where(df["Anomaly"] == -1, "Anomaly", "Normal")

# Training table for location model
area_codes = {a:i for i,a in enumerate(sorted(df["Area"].unique()))}
train = df[df["Person_ID"] == case["Person_ID"]].copy()
if len(train) < 30:
    train = df.copy()

train["Average_Speed"] = case["Average_Speed"]
train["Average_Distance"] = case["Average_Distance"]
train["Last_Area_Code"] = area_codes.get(case["Last_Area"], 0)
train["Previous_Area_Code"] = area_codes.get(case["Previous_Area"], 0)
train["Time_Since_Last_Seen"] = case["Time_Since_Last_Seen"]

features = ["Hour","DayOfWeek","Weekend","Average_Speed","Average_Distance",
            "Last_Area_Code","Previous_Area_Code","Time_Since_Last_Seen"]
target = "Area"

rf = RandomForestClassifier(n_estimators=200, max_depth=12, random_state=42, class_weight="balanced")
rf.fit(train[features], train[target])

# Case feature vector
case_time = pd.to_datetime(case["Last_Seen_Time"])
X_case = pd.DataFrame([{
    "Hour": case_time.hour,
    "DayOfWeek": case_time.dayofweek,
    "Weekend": int(case_time.dayofweek in [5,6]),
    "Average_Speed": case["Average_Speed"],
    "Average_Distance": case["Average_Distance"],
    "Last_Area_Code": area_codes.get(case["Last_Area"],0),
    "Previous_Area_Code": area_codes.get(case["Previous_Area"],0),
    "Time_Since_Last_Seen": case["Time_Since_Last_Seen"]
}])

probs = rf.predict_proba(X_case)[0]
classes = rf.classes_
ranked = sorted(zip(classes, probs), key=lambda x:x[1], reverse=True)

# Markov transition table
trans = pd.crosstab(df["Area"], df["Area"].shift(-1), normalize="index").fillna(0)
current = case["Last_Area"]
route = [current]
for _ in range(3):
    if current in trans.index:
        nxt = trans.loc[current].sort_values(ascending=False).index[0]
        route.append(nxt)
        current = nxt

# Search-priority score
visit_freq = df["Area"].value_counts(normalize=True)
scores = []
for area, p in ranked:
    prediction_score = p * 100
    historical = visit_freq.get(area,0) * 100
    route_similarity = 100 if area in route else 30
    distance_relevance = 80 if area == case["Last_Area"] else 55
    time_relevance = 80 if area == case["Usual_Area"] else 50
    anomaly_evidence = 70 if ((df[df["Area"]==area]["Anomaly"]==-1).mean() > 0.05) else 30
    score = (
        0.30*prediction_score + 0.20*historical +
        0.15*route_similarity + 0.15*distance_relevance +
        0.10*time_relevance + 0.10*anomaly_evidence
    )
    scores.append((area, score))

priority_df = pd.DataFrame(scores, columns=["Area","Priority Score"]).sort_values("Priority Score", ascending=False)
priority_df["Priority"] = pd.cut(
    priority_df["Priority Score"],
    bins=[-1,30,60,80,101],
    labels=["Low","Medium","High","Very High"]
)

# Metrics
c1,c2,c3,c4 = st.columns(4)
c1.metric("Fictional Case", case_id)
c2.metric("Last Known Area", case["Last_Area"])
c3.metric("Anomalies", int((df["Anomaly"]==-1).sum()))
c4.metric("Top Predicted Area", ranked[0][0])

st.divider()

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["🎯 Location Prediction","⚠️ Anomaly Detection","🧭 Route Prediction","🗺️ Map","🔍 Explainability"]
)

with tab1:
    st.subheader("Probable Areas")
    pred_df = pd.DataFrame(ranked, columns=["Area","Probability"])
    pred_df["Probability"] = (pred_df["Probability"]*100).round(2)
    st.dataframe(pred_df, use_container_width=True)
    st.bar_chart(pred_df.set_index("Area")["Probability"])

with tab2:
    st.subheader("Synthetic Movement Anomalies")
    st.write("Isolation Forest identifies movement observations that differ from the learned pattern.")
    st.dataframe(
        df[df["Anomaly"]==-1][["Person_ID","Timestamp","Latitude","Longitude","Speed_kmh","Distance_km","Area"]].head(50),
        use_container_width=True
    )

with tab3:
    st.subheader("Markov-Chain Route Prediction")
    st.write(" → ".join(route))
    st.info("This is a transition-probability demonstration using synthetic movement history.")

with tab4:
    st.subheader("Interactive Map")
    m = folium.Map(location=[23.26,77.42], zoom_start=12)
    folium.Marker(
        AREA_COORDS[case["Last_Area"]],
        popup=f"Last known area: {case['Last_Area']}",
        icon=folium.Icon(icon="info-sign")
    ).add_to(m)
    for area, p in ranked:
        folium.CircleMarker(
            AREA_COORDS[area], radius=8,
            popup=f"{area}: {p*100:.1f}%"
        ).add_to(m)
    points=[AREA_COORDS[a] for a in route]
    folium.PolyLine(points, weight=4, popup="Synthetic probable route").add_to(m)
    st_folium(m, width=1000, height=550)

with tab5:
    st.subheader("Why did the model rank areas differently?")
    top_area = ranked[0][0]
    reasons = []
    if visit_freq.get(top_area,0) > visit_freq.mean():
        reasons.append("High historical visit frequency")
    if top_area in route:
        reasons.append("Area appears in the Markov transition route")
    if top_area == case["Usual_Area"]:
        reasons.append("Matches the synthetic usual area")
    if top_area == case["Last_Area"]:
        reasons.append("Matches the last known area")
    reasons.append("Random Forest probability contributes 30% of the priority score")
    for r in reasons:
        st.success("✓ " + r)

    imp = pd.DataFrame({"Feature":features, "Importance":rf.feature_importances_}).sort_values("Importance", ascending=False)
    st.subheader("Random Forest Feature Importance")
    st.bar_chart(imp.set_index("Feature"))

st.divider()
st.subheader("Search Priority Score")
st.dataframe(priority_df, use_container_width=True)

st.warning("Ethical note: This project is an academic simulation. Model outputs are probabilistic, may contain false positives/negatives, and must not be used to infer a real person's location or wrongdoing.")
