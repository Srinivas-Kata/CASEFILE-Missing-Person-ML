
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

FEATURES = [
    "Hour","DayOfWeek","Weekend","Average_Speed","Average_Distance",
    "Last_Area_Code","Previous_Area_Code","Time_Since_Last_Seen"
]

def build_training_table(df, cases):
    # Simple academic construction: each case is paired with historical movement rows.
    out = []
    area_to_code = {a:i for i,a in enumerate(sorted(df["Area"].unique()))}
    for _, c in cases.iterrows():
        temp = df[df["Person_ID"] == c["Person_ID"]].copy()
        if temp.empty:
            continue
        temp["Average_Speed"] = c["Average_Speed"]
        temp["Average_Distance"] = c["Average_Distance"]
        temp["Last_Area_Code"] = area_to_code.get(c["Last_Area"], 0)
        temp["Previous_Area_Code"] = area_to_code.get(c["Previous_Area"], 0)
        temp["Time_Since_Last_Seen"] = c["Time_Since_Last_Seen"]
        out.append(temp)
    return pd.concat(out, ignore_index=True), area_to_code

def train_location_model(train_df):
    model = RandomForestClassifier(
        n_estimators=200, random_state=42, max_depth=12, class_weight="balanced"
    )
    model.fit(train_df[FEATURES], train_df["Area"])
    return model
