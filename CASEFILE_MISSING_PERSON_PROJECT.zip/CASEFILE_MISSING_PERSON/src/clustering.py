
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

FEATURES = ["Latitude","Longitude","Speed_kmh","Distance_km"]

def train_clustering(df, n_clusters=5):
    scaler = StandardScaler()
    X = scaler.fit_transform(df[FEATURES])
    model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = model.fit_predict(X)
    return model, scaler, labels
