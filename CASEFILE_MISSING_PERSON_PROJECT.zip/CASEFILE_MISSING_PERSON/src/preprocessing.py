
import pandas as pd
import numpy as np

def load_and_prepare(path):
    df = pd.read_csv(path)
    df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
    df = df.drop_duplicates().dropna(subset=["Latitude","Longitude","Timestamp"])
    df = df[(df["Latitude"].between(-90,90)) & (df["Longitude"].between(-180,180))]
    df["Hour"] = df["Timestamp"].dt.hour
    df["DayOfWeek"] = df["Timestamp"].dt.dayofweek
    df["Weekend"] = df["DayOfWeek"].isin([5,6]).astype(int)
    df["Month"] = df["Timestamp"].dt.month
    return df
