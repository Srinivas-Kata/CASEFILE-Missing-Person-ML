
from sklearn.ensemble import IsolationForest

FEATURES = ["Latitude","Longitude","Speed_kmh","Distance_km","Hour"]

def train_anomaly(df):
    model = IsolationForest(
        n_estimators=150, contamination=0.05, random_state=42
    )
    model.fit(df[FEATURES])
    return model
