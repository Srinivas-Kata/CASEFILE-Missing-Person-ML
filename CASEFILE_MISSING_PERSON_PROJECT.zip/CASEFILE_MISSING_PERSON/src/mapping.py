
import folium

AREA_COORDS = {
    "Area_A": (23.2599, 77.4126),
    "Area_B": (23.2480, 77.4340),
    "Area_C": (23.2710, 77.3980),
    "Area_D": (23.2350, 77.4210),
    "Area_E": (23.2850, 77.4400),
}

def make_map(case_area, ranked_areas, route):
    m = folium.Map(location=[23.26,77.42], zoom_start=12)
    folium.Marker(
        AREA_COORDS[case_area], popup=f"Last known area: {case_area}",
        icon=folium.Icon(icon="info-sign")
    ).add_to(m)

    for area, prob in ranked_areas:
        folium.CircleMarker(
            AREA_COORDS[area], radius=8,
            popup=f"{area}: {prob:.1f}%"
        ).add_to(m)

    points = [AREA_COORDS[a] for a in route if a in AREA_COORDS]
    if len(points) > 1:
        folium.PolyLine(points, weight=4, popup="Synthetic probable route").add_to(m)
    return m
