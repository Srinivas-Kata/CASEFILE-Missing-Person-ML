# Dataset Documentation

## Synthetic movement data
File: data/raw/synthetic_movement_raw.csv
Purpose: academic demonstration of movement-pattern ML.
Fields: Person_ID, Timestamp, Latitude, Longitude, Speed_kmh, Distance_km, Area.

## Synthetic cases
File: data/synthetic/missing_person_cases.csv
Purpose: fictional case inputs for the dashboard.
All case identities are fictional.

## Public reference dataset
Microsoft GeoLife GPS Trajectory Dataset:
https://www.microsoft.com/en-us/research/publication/geolife-gps-trajectory-dataset-user-guide/

## Mapping reference
OpenStreetMap:
https://www.openstreetmap.org/
