CASEFILE: AN AI-POWERED MISSING PERSON INVESTIGATION AND PROBABLE LOCATION PREDICTION SYSTEM USING ADVANCED MACHINE LEARNING

ABSTRACT
This project presents an academic simulation of an investigation-support dashboard that analyzes movement data and ranks probable geographical areas for a fictional case. The system combines unsupervised learning, anomaly detection, supervised learning, transition probabilities, geospatial visualization, and explainability.

1. INTRODUCTION
Large movement datasets contain repeated spatial and temporal patterns. Machine learning can be used to summarize those patterns and identify observations that differ from normal behavior. This project demonstrates those ideas using synthetic case information.

2. PROBLEM STATEMENT
The objective is to build an ML-based system that analyzes historical movement patterns and produces a ranked list of probable areas and routes for a fictional case.

3. OBJECTIVES
- Preprocess movement data.
- Engineer time and movement features.
- Cluster movement patterns.
- Detect anomalies.
- Predict probable areas.
- Predict a probable route.
- Calculate search-priority scores.
- Explain model outputs.
- Visualize results on an interactive map.
- Provide a Streamlit dashboard.

4. DATASET
The implementation includes synthetic movement and fictional case data. The public reference dataset is the Microsoft GeoLife GPS Trajectory Dataset. GeoLife contains GPS trajectories collected from 182 users over more than three years and includes timestamped latitude, longitude and altitude information.

5. PREPROCESSING
Duplicate records and invalid coordinates are removed. Timestamps are converted to datetime. Hour, weekday, weekend and month features are extracted.

6. FEATURE ENGINEERING
Features include latitude, longitude, speed, distance, hour, weekday, weekend status, visit frequency and case-context features.

7. METHODOLOGY
K-Means is used to group movement observations.
Isolation Forest is used to identify unusual observations.
Random Forest is used to classify the probable destination area.
A Markov transition table is used to estimate a likely sequence of areas.
A weighted score combines prediction probability, historical frequency, route similarity, distance relevance, time relevance and anomaly evidence.

8. EVALUATION
The dashboard exposes prediction probabilities and movement-analysis results. For a formal submission, accuracy, precision, recall and F1-score should be reported from an appropriate held-out evaluation split. Anomaly detection should be discussed using anomaly counts and threshold/contamination choices.

9. EXPLAINABILITY
Random Forest feature importance and rule-based supporting factors are displayed to show why an area received a higher priority score.

10. DASHBOARD
The Streamlit application contains case selection, probable areas, anomaly observations, route prediction, interactive map, explainability and search-priority tables.

11. LIMITATIONS
The dataset and case records are synthetic. The models are demonstrations rather than validated investigative systems. Predictions may be wrong and should not be interpreted as proof of a person's location.

12. ETHICAL CONSIDERATIONS
No private missing-person records or personally identifiable information are used. The application is an academic simulation. Anomaly labels do not imply criminality or suspicious behavior.

13. FUTURE SCOPE
Future work could use larger public mobility datasets, calibrated probability estimates, better geospatial models, SHAP explanations, graph-based route modeling and more rigorous cross-validation.

14. CONCLUSION
The project demonstrates an integrated Advanced Machine Learning pipeline consisting of clustering, anomaly detection, supervised prediction, route transition modeling, scoring, explainability, mapping and a Streamlit interface.
