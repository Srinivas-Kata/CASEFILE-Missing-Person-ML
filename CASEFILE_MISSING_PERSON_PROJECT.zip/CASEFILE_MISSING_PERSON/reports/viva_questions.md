# Viva Questions and Short Answers

1. Why did you use K-Means?
K-Means groups movement observations into clusters with similar characteristics.

2. Why Isolation Forest?
It is an unsupervised anomaly-detection method that isolates unusual observations using random tree partitions.

3. What does an anomaly mean?
It means the observation differs from the learned movement pattern. It does not prove suspicious or criminal behavior.

4. Why Random Forest?
It is a supervised ensemble classifier that can model nonlinear relationships and provides feature importance.

5. Why Markov Chain?
It models transitions between areas and can estimate the next likely area from the current area.

6. What is the search-priority score?
It is a weighted combination of prediction probability and other movement-related factors.

7. Why Streamlit?
It provides a simple way to turn Python ML code into an interactive web application.

8. What is explainable AI in this project?
Random Forest feature importance plus understandable factors such as visit frequency, route similarity and time similarity.

9. What is the biggest limitation?
The project is a synthetic academic simulation and the predictions are probabilistic.

10. Can the system prove where a missing person is?
No. It only demonstrates probable areas from the available synthetic data.
