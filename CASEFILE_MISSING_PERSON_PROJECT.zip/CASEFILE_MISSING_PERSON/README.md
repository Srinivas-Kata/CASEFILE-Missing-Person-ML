# CASEFILE – AI-Powered Missing Person Investigation and Probable Location Prediction

## Academic Project
This repository is an academic simulation. It uses synthetic missing-person case records and synthetic movement data. It must not be used for real-world missing-person investigations or decisions.

## Main ML techniques
- K-Means clustering – movement pattern grouping
- Isolation Forest – anomaly detection
- Random Forest – probable area classification
- Markov Chain / transition probabilities – route prediction
- Weighted search-priority score
- Random Forest feature importance for explainability
- Folium interactive map
- Streamlit dashboard

## Run locally

```bash
pip install -r requirements.txt
streamlit run app/app.py
```

## Dataset
The project is designed around the Microsoft GeoLife GPS Trajectory Dataset as the public reference dataset. For the simple college implementation in this repository, the included CSV is synthetic so that no private or personally identifiable missing-person information is used.

Official GeoLife source:
https://www.microsoft.com/en-us/research/publication/geolife-gps-trajectory-dataset-user-guide/

OpenStreetMap:
https://www.openstreetmap.org/

## Disclaimer
Predictions are probabilistic. An anomaly is not evidence of criminal behavior. This application is for academic demonstration only.
